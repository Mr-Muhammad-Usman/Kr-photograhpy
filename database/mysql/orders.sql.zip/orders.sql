-- phpMyAdmin SQL Dump
-- version 5.1.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 13, 2022 at 05:30 PM
-- Server version: 10.4.18-MariaDB
-- PHP Version: 8.0.3

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kr_photogs`
--

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `id` int(11) NOT NULL,
  `competition_name` varchar(255) DEFAULT NULL,
  `competition_date` date DEFAULT NULL,
  `user_id` varchar(255) DEFAULT NULL,
  `price` varchar(255) DEFAULT NULL,
  `payer_id` varchar(255) DEFAULT NULL,
  `status` varchar(255) DEFAULT NULL,
  `redeem_code` varchar(255) DEFAULT NULL,
  `receipt_url` varchar(255) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  `updated_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`id`, `competition_name`, `competition_date`, `user_id`, `price`, `payer_id`, `status`, `redeem_code`, `receipt_url`, `created_at`, `updated_at`) VALUES
(4, 'Maxime illum tenetu', '2022-05-21', '2', '10', 'ch_3KycAHFo3JNYSfwX1TsQyKwM', 'succeeded', '202205121652362489567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KycAHFo3JNYSfwX1TsQyKwM/rcpt_Lfy6lvIs92pBhOQHAk3rXLm46oVGWTv', '2022-05-12 08:34:49', '2022-05-12 08:34:49'),
(5, 'Voluptatem et ipsum', '2022-05-13', '21', '10', 'ch_3KydPmFo3JNYSfwX1KitOEUs', 'succeeded', '202205121652367294567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KydPmFo3JNYSfwX1KitOEUs/rcpt_LfzO1mpvRnfy6u1xa9ZjcfDYLL4qL7z', '2022-05-12 09:54:54', '2022-05-12 09:54:54'),
(6, 'Maxime illum tenetu', '2022-05-26', '22', '10', 'ch_3KydXEFo3JNYSfwX0ijhRgep', 'succeeded', '202205121652367756567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KydXEFo3JNYSfwX0ijhRgep/rcpt_LfzWBmTcHJLm8AJKkynpGgenJXX1YsV', '2022-05-12 10:02:36', '2022-05-12 10:02:36'),
(7, 'Maxime illum tenetu', '2022-05-10', '23', '10', 'ch_3KydZMFo3JNYSfwX0J0AnOCE', 'succeeded', '202205121652367888567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KydZMFo3JNYSfwX0J0AnOCE/rcpt_LfzYjC2BzUVccmZPxisvqUOdLjHplgt', '2022-05-12 10:04:48', '2022-05-12 10:04:48'),
(8, 'Maxime illum tenetu', '2022-05-20', '24', '10', 'ch_3KydaPFo3JNYSfwX0jMu4krz', 'succeeded', '202205121652367953567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KydaPFo3JNYSfwX0jMu4krz/rcpt_LfzZvjKx7vFVEPq3OX2bsOPHkLmih9D', '2022-05-12 10:05:53', '2022-05-12 10:05:53'),
(9, 'Dolorem totam conseq', '2022-05-19', '29', '10', 'ch_3Kyg1RFo3JNYSfwX0AOKKfiv', 'succeeded', '202205121652377319567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3Kyg1RFo3JNYSfwX0AOKKfiv/rcpt_Lg25uv9kfUD98htQUDCaGwp1Shbak6d', '2022-05-12 12:41:59', '2022-05-12 12:41:59'),
(10, 'Qui facere ut itaque', '1997-03-26', '30', '10', 'ch_3KygRYFo3JNYSfwX0qngzk4E', 'succeeded', '202205121652378936567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KygRYFo3JNYSfwX0qngzk4E/rcpt_Lg2WBvKqngqApdVXeC20CaRFEbV6yz5', '2022-05-12 13:08:56', '2022-05-12 13:08:56'),
(11, 'Qui facere ut itaque', '2004-04-26', '31', '10', 'ch_3KygUCFo3JNYSfwX1hq2VVwI', 'succeeded', '202205121652379100567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KygUCFo3JNYSfwX1hq2VVwI/rcpt_Lg2Z6bZHT14QKyRGiTkRqiw6Xzc8GXr', '2022-05-12 13:11:40', '2022-05-12 13:11:40'),
(12, 'Maxime illum tenetu', '2022-05-18', '34', '10', 'ch_3KygheFo3JNYSfwX1NAQh6Ji', 'succeeded', '202205121652379934567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KygheFo3JNYSfwX1NAQh6Ji/rcpt_Lg2nIIFAYVqlCwDMM4gLUjqrG76RLRq', '2022-05-12 13:25:34', '2022-05-12 13:25:34'),
(13, 'Dolorem totam conseq', '2022-05-19', '35', '10', 'ch_3KyhJtFo3JNYSfwX1LKTbzXM', 'succeeded', '202205121652382305567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KyhJtFo3JNYSfwX1LKTbzXM/rcpt_Lg3Q5eBfyi8etHmQLzBcQpJxTQsiFCS', '2022-05-12 14:05:05', '2022-05-12 14:05:05'),
(14, 'Maxime illum tenetu', '2022-05-28', '36', '10', 'ch_3KyhNMFo3JNYSfwX1I3QEnm4', 'succeeded', '202205121652382520567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KyhNMFo3JNYSfwX1I3QEnm4/rcpt_Lg3UwML2JrCjzFl070ljbPWaBvKxBtU', '2022-05-12 14:08:40', '2022-05-12 14:08:40'),
(15, 'Maxime illum tenetu', '2022-05-21', '37', '10', 'ch_3Kyw8ZFo3JNYSfwX1zU6s78P', 'succeeded', '202205131652439265567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3Kyw8ZFo3JNYSfwX1zU6s78P/rcpt_LgIkr9BMptZABOHDL4Mj22wIvPMuqqN', '2022-05-13 05:54:25', '2022-05-13 05:54:25'),
(16, 'Maxime illum tenetu', '2022-05-28', '39', '10', 'ch_3Kywe6Fo3JNYSfwX1BZckVTQ', 'succeeded', '202205131652441220567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3Kywe6Fo3JNYSfwX1BZckVTQ/rcpt_LgJGUmcwo9N8NV6RQisa9yYBAsHoMyy', '2022-05-13 06:27:00', '2022-05-13 06:27:00'),
(17, 'Dolorem totam conseq', '2022-05-20', '40', '10', 'ch_3KywvIFo3JNYSfwX1QZw77Yq', 'succeeded', '202205131652442286567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3KywvIFo3JNYSfwX1QZw77Yq/rcpt_LgJYTCuYGep7BSGw4Thn2ex8doYi734', '2022-05-13 06:44:46', '2022-05-13 06:44:46'),
(18, 'Dolorem totam conseq', '2022-05-25', '41', '10', 'ch_3Kyyj8Fo3JNYSfwX15ZpCzhh', 'succeeded', '202205131652449219567891', 'https://pay.stripe.com/receipts/acct_1KnhCEFo3JNYSfwX/ch_3Kyyj8Fo3JNYSfwX15ZpCzhh/rcpt_LgLP9t4YfyuWWf5hWpq6bUu20JmKHCS', '2022-05-13 08:40:19', '2022-05-13 08:40:19');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
